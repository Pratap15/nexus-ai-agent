import { useState, useEffect, useRef, useCallback } from "react";

/* ─── CONSTANTS ────────────────────────────────────────────── */
const API = "http://localhost:8000";
const WS  = "ws://localhost:8000/ws/agent";

const MODELS = [
  { id:"nemotron-super", name:"NEMOTRON·3 SUPER", sub:"120B · A12B",  color:"#00ffe5", glow:"0 0 20px #00ffe580" },
  { id:"mistral-small",  name:"MISTRAL·SMALL·4", sub:"119B · FAST",   color:"#ff6b35", glow:"0 0 20px #ff6b3580" },
  { id:"kimi-k2",        name:"KIMI·K2.5·MOE",   sub:"MoE · DEEP",   color:"#c77dff", glow:"0 0 20px #c77dff80" },
  { id:"minimax-m2",     name:"MINIMAX·M2.5",     sub:"CODING·OPS",   color:"#4cc9f0", glow:"0 0 20px #4cc9f080" },
];

const FORMATS = [
  { id:"txt",  label:"TXT",  icon:"📄", desc:"Plain text notepad" },
  { id:"md",   label:"MD",   icon:"📝", desc:"Markdown report" },
  { id:"csv",  label:"CSV",  icon:"📊", desc:"Spreadsheet data" },
  { id:"code", label:"CODE", icon:"⌨", desc:"Source code file" },
];

const PRESETS = [
  { label:"AI TRENDS 2025",    task:"Research the top 10 AI model releases and breakthroughs in 2025. Save a comprehensive CSV with columns: Model, Company, Release_Date, Key_Feature, Use_Case." },
  { label:"GPU BENCHMARK",     task:"Search for NVIDIA vs AMD GPU performance benchmarks 2025. Create a CSV with columns: GPU_Model, Brand, VRAM_GB, FPS_4K, Price_USD, Value_Score." },
  { label:"PYTHON LIBRARIES",  task:"Find the top 15 Python libraries for data science and machine learning. Save a CSV: Library, Category, Stars_GitHub, Latest_Version, Best_For." },
  { label:"CRYPTO MONITOR",    task:"Search for current Bitcoin, Ethereum, and top 5 altcoin prices and market data. Save a CSV with: Coin, Price_USD, 24h_Change, Market_Cap, Volume_24h." },
  { label:"WEB SCRAPER CODE",  task:"Write a complete Python web scraper using httpx and BeautifulSoup that scrapes news headlines from a website, stores results in a CSV. Include error handling and comments." },
  { label:"TECH NEWS BRIEF",   task:"Search for the latest technology news across AI, chips, cloud computing, and cybersecurity. Write a detailed markdown report with sections and bullet points." },
];

function formatBytes(b) {
  if (b < 1024) return b + " B";
  if (b < 1048576) return (b/1024).toFixed(1) + " KB";
  return (b/1048576).toFixed(2) + " MB";
}

function timestamp() {
  return new Date().toLocaleTimeString('en-US', { hour12: false });
}

/* ─── MAIN APP ──────────────────────────────────────────────── */
export default function App() {
  const [tab, setTab] = useState("mission");  // mission | intel | databank
  const [model, setModel] = useState("nemotron-super");
  const [task, setTask] = useState("");
  const [filename, setFilename] = useState("");
  const [format, setFormat] = useState("txt");
  const [running, setRunning] = useState(false);
  const [logs, setLogs] = useState([]);
  const [files, setFiles] = useState([]);
  const [health, setHealth] = useState(null);
  const [particles, setParticles] = useState([]);
  const [scanY, setScanY] = useState(0);
  const [glitch, setGlitch] = useState(false);
  const wsRef = useRef(null);
  const logsRef = useRef(null);
  const scanRef = useRef(null);

  /* ── scan line animation ── */
  useEffect(() => {
    scanRef.current = setInterval(() => {
      setScanY(y => (y >= 100 ? 0 : y + 0.3));
    }, 16);
    return () => clearInterval(scanRef.current);
  }, []);

  /* ── boot sequence ── */
  useEffect(() => {
    setParticles(Array.from({length:30}, (_,i) => ({
      id:i,
      x: Math.random()*100,
      y: Math.random()*100,
      size: Math.random()*2+0.5,
      speed: Math.random()*0.3+0.1,
      opacity: Math.random()*0.5+0.1,
    })));

    checkHealth();
    loadFiles();
    const iv = setInterval(loadFiles, 4000);

    // random glitch
    const giv = setInterval(() => {
      if (Math.random() < 0.1) {
        setGlitch(true);
        setTimeout(() => setGlitch(false), 120);
      }
    }, 3000);

    return () => { clearInterval(iv); clearInterval(giv); };
  }, []);

  useEffect(() => {
    logsRef.current?.scrollTo({ top: 9999, behavior: "smooth" });
  }, [logs]);

  async function checkHealth() {
    try {
      const r = await fetch(`${API}/health`);
      setHealth(await r.json());
    } catch { setHealth(null); }
  }

  async function loadFiles() {
    try {
      const r = await fetch(`${API}/files`);
      setFiles(await r.json());
    } catch {}
  }

  function log(type, content, extra={}) {
    setLogs(p => [...p, { id: Date.now()+Math.random(), type, content, extra, time: timestamp() }]);
  }

  function runAgent() {
    if (!task.trim() || running) return;
    setLogs([]);
    setRunning(true);
    setTab("intel");

    const ws = new WebSocket(WS);
    wsRef.current = ws;

    ws.onopen = () => {
      ws.send(JSON.stringify({ task: task.trim(), model, filename: filename.trim()||null, format }));
      log("boot", "NEXUS AGENT SYSTEM ONLINE");
      log("boot", `MODEL: ${model.toUpperCase()} | FORMAT: ${format.toUpperCase()}`);
      log("boot", "─".repeat(50));
    };

    ws.onmessage = ({ data }) => {
      const msg = JSON.parse(data);

      if (msg.type === "token") {
        setLogs(p => {
          const last = p[p.length-1];
          if (last?.type === "stream")
            return [...p.slice(0,-1), {...last, content: last.content + msg.content}];
          return [...p, {id:Date.now(), type:"stream", content:msg.content, time:timestamp()}];
        });
        return;
      }

      const handlers = {
        status:        () => log("status",  msg.content, { phase: msg.phase }),
        searching:     () => log("search",  `[SCAN] ${msg.query}`),
        search_result: () => log("result",  msg.content, { query: msg.query }),
        fetching:      () => log("fetch",   `[FETCH] ${msg.url}`),
        file_saved:    () => { log("save", `[SAVED] ${msg.filename} (${formatBytes(msg.size)})`); loadFiles(); },
        done:          () => log("done",    `[DONE] ${msg.summary}`),
        complete:      () => { log("complete", "MISSION COMPLETE — ALL SYSTEMS NOMINAL"); setRunning(false); loadFiles(); },
        error:         () => { log("error", `[ERROR] ${msg.content}`); setRunning(false); },
      };
      handlers[msg.type]?.();
    };

    ws.onerror = () => {
      log("error", "[OFFLINE] Cannot reach NEXUS backend. Is Python server running?");
      setRunning(false);
    };

    ws.onclose = () => { if (running) setRunning(false); };
  }

  function stopAgent() {
    wsRef.current?.close();
    log("warn", "[ABORT] Mission terminated by operator");
    setRunning(false);
  }

  const selectedModel = MODELS.find(m => m.id === model);

  return (
    <div style={{ minHeight:"100vh", background:"#020408", color:"#a0c4cc", fontFamily:"'Share Tech Mono','Courier New',monospace", position:"relative", overflow:"hidden" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Orbitron:wght@400;600;800&display=swap');

        * { box-sizing:border-box; margin:0; padding:0; }
        ::-webkit-scrollbar { width:4px; }
        ::-webkit-scrollbar-track { background:#020408; }
        ::-webkit-scrollbar-thumb { background:#00ffe520; border-radius:2px; }

        .hud-border {
          border:1px solid #00ffe520;
          position:relative;
        }
        .hud-border::before, .hud-border::after {
          content:'';
          position:absolute;
          width:8px; height:8px;
          border-color:#00ffe5;
          border-style:solid;
        }
        .hud-border::before { top:-1px; left:-1px; border-width:1px 0 0 1px; }
        .hud-border::after  { bottom:-1px; right:-1px; border-width:0 1px 1px 0; }

        .orb { font-family:'Orbitron',sans-serif; }

        .tab-btn {
          font-family:'Orbitron',sans-serif;
          font-size:10px;
          letter-spacing:0.15em;
          padding:8px 20px;
          border:none;
          background:transparent;
          cursor:pointer;
          transition:all 0.2s;
          position:relative;
          color:#3d6b72;
        }
        .tab-btn.active {
          color:#00ffe5;
          text-shadow:0 0 10px #00ffe5;
        }
        .tab-btn.active::after {
          content:'';
          position:absolute;
          bottom:0; left:0; right:0;
          height:1px;
          background:linear-gradient(90deg,transparent,#00ffe5,transparent);
        }
        .tab-btn:hover:not(.active) { color:#5a9da6; }

        .model-chip {
          padding:10px 14px;
          border:1px solid #0d2428;
          border-radius:3px;
          cursor:pointer;
          transition:all 0.15s;
          background:#020c0e;
          position:relative;
          overflow:hidden;
        }
        .model-chip::before {
          content:'';
          position:absolute;
          top:0; left:0; bottom:0;
          width:2px;
        }
        .model-chip:hover { border-color:#00ffe520; }
        .model-chip.active { border-color:var(--mc); background:color-mix(in srgb,var(--mc) 5%,#020c0e); }
        .model-chip.active::before { background:var(--mc); box-shadow:var(--mg); }

        .fmt-btn {
          flex:1;
          padding:8px 4px;
          border:1px solid #0d2428;
          background:#020c0e;
          color:#3d6b72;
          font-family:'Share Tech Mono',monospace;
          font-size:11px;
          cursor:pointer;
          transition:all 0.15s;
          border-radius:2px;
        }
        .fmt-btn:hover { border-color:#00ffe530; color:#00ffe580; }
        .fmt-btn.active { border-color:#00ffe5; color:#00ffe5; background:#00ffe508; box-shadow:0 0 8px #00ffe520; }

        .run-btn {
          font-family:'Orbitron',sans-serif;
          font-size:11px;
          letter-spacing:0.2em;
          padding:12px 24px;
          border:1px solid #00ffe5;
          background:transparent;
          color:#00ffe5;
          cursor:pointer;
          transition:all 0.2s;
          position:relative;
          overflow:hidden;
          text-shadow:0 0 10px #00ffe5;
          box-shadow:0 0 15px #00ffe510, inset 0 0 15px #00ffe508;
        }
        .run-btn:hover:not(:disabled) {
          background:#00ffe510;
          box-shadow:0 0 30px #00ffe530, inset 0 0 20px #00ffe510;
        }
        .run-btn:disabled { opacity:0.3; cursor:not-allowed; }
        .run-btn.running {
          border-color:#ff6b35;
          color:#ff6b35;
          text-shadow:0 0 10px #ff6b35;
          box-shadow:0 0 15px #ff6b3520, inset 0 0 10px #ff6b3508;
          animation:pulse-run 1.5s ease-in-out infinite;
        }
        @keyframes pulse-run { 0%,100%{opacity:1} 50%{opacity:0.7} }

        .stop-btn {
          font-family:'Orbitron',sans-serif;
          font-size:10px;
          letter-spacing:0.15em;
          padding:12px 16px;
          border:1px solid #ff6b3550;
          background:transparent;
          color:#ff6b35;
          cursor:pointer;
          transition:all 0.15s;
        }
        .stop-btn:hover { background:#ff6b3510; box-shadow:0 0 10px #ff6b3530; }

        input, textarea, select {
          font-family:'Share Tech Mono',monospace;
          font-size:12px;
          background:#020c0e;
          border:1px solid #0d2428;
          color:#a0c4cc;
          padding:10px 12px;
          outline:none;
          transition:border-color 0.15s;
          width:100%;
          border-radius:2px;
        }
        input:focus, textarea:focus { border-color:#00ffe530; box-shadow:0 0 8px #00ffe510; }
        input::placeholder, textarea::placeholder { color:#1d4048; }

        .log-line { display:flex; gap:10px; font-size:12px; line-height:1.7; padding:1px 0; }
        .log-time { color:#1a4048; min-width:50px; font-size:11px; }

        .file-row {
          display:flex; align-items:center; gap:10px;
          padding:10px 12px;
          border:1px solid #0a1e22;
          background:#020c0e;
          border-radius:2px;
          transition:border-color 0.15s;
        }
        .file-row:hover { border-color:#00ffe520; }

        .dl-btn {
          font-family:'Share Tech Mono',monospace;
          font-size:11px;
          padding:5px 12px;
          border:1px solid #0d2428;
          background:transparent;
          color:#3d6b72;
          cursor:pointer;
          transition:all 0.15s;
          border-radius:2px;
        }
        .dl-btn:hover { border-color:#00ffe530; color:#00ffe5; }

        .glitch { animation:glitch 0.12s steps(2) forwards; }
        @keyframes glitch {
          0%  { transform:translate(2px,0) skewX(0.5deg); filter:hue-rotate(90deg); }
          25% { transform:translate(-2px,1px) skewX(-0.5deg); }
          50% { transform:translate(1px,-1px); filter:hue-rotate(180deg); }
          75% { transform:translate(-1px,0); }
          100%{ transform:none; filter:none; }
        }

        .typing::after {
          content:'▋';
          animation:blink 1s step-end infinite;
          color:#00ffe5;
        }
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }

        .scanline {
          position:fixed; left:0; right:0; height:2px;
          background:linear-gradient(transparent,#00ffe508,transparent);
          pointer-events:none; z-index:9999;
          transition:top 0.016s linear;
        }

        .particle {
          position:fixed;
          border-radius:50%;
          pointer-events:none;
          z-index:0;
          animation:float var(--spd) ease-in-out infinite alternate;
        }
        @keyframes float {
          from { transform:translateY(0px); }
          to   { transform:translateY(-15px); }
        }

        .status-dot {
          width:6px; height:6px; border-radius:50%;
          animation:pulse-dot 2s ease-in-out infinite;
        }
        @keyframes pulse-dot { 0%,100%{box-shadow:0 0 0 0 currentColor} 50%{box-shadow:0 0 0 4px transparent} }

        .grid-bg {
          position:fixed; inset:0;
          background-image:
            linear-gradient(#00ffe504 1px,transparent 1px),
            linear-gradient(90deg,#00ffe504 1px,transparent 1px);
          background-size:40px 40px;
          pointer-events:none; z-index:0;
        }

        .hexagon {
          position:fixed;
          opacity:0.03;
          pointer-events:none;
          z-index:0;
          animation:rotate-hex 20s linear infinite;
        }
        @keyframes rotate-hex { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }

        .preset-item {
          padding:6px 10px;
          font-size:10px;
          color:#2a5058;
          cursor:pointer;
          border:1px solid transparent;
          border-radius:2px;
          transition:all 0.1s;
          letter-spacing:0.08em;
        }
        .preset-item:hover { color:#00ffe5; border-color:#00ffe520; background:#00ffe505; }
      `}</style>

      {/* Background */}
      <div className="grid-bg" />
      <div className="scanline" style={{ top: `${scanY}%` }} />

      {/* Particles */}
      {particles.map(p => (
        <div key={p.id} className="particle" style={{
          left:`${p.x}%`, top:`${p.y}%`,
          width:p.size, height:p.size,
          background:`#00ffe5`,
          opacity:p.opacity,
          "--spd":`${2+p.speed*10}s`,
          animationDelay:`${p.id*0.3}s`,
        }} />
      ))}

      {/* Hex decoration */}
      <svg className="hexagon" style={{width:600,height:600,left:"-10%",top:"-10%"}} viewBox="0 0 100 100">
        <polygon points="50,2 90,26 90,74 50,98 10,74 10,26" fill="none" stroke="#00ffe5" strokeWidth="0.5"/>
        <polygon points="50,15 80,32 80,68 50,85 20,68 20,32" fill="none" stroke="#00ffe5" strokeWidth="0.3"/>
      </svg>
      <svg className="hexagon" style={{width:400,height:400,right:"-5%",bottom:"10%",animationDuration:"30s",animationDirection:"reverse"}} viewBox="0 0 100 100">
        <polygon points="50,2 90,26 90,74 50,98 10,74 10,26" fill="none" stroke="#c77dff" strokeWidth="0.5"/>
      </svg>

      {/* Main layout */}
      <div style={{ position:"relative", zIndex:1, display:"flex", flexDirection:"column", minHeight:"100vh" }}>

        {/* ── HEADER ── */}
        <header style={{
          borderBottom:"1px solid #0a2028",
          padding:"0 24px",
          background:"linear-gradient(180deg,#030b0f,transparent)",
          display:"flex", alignItems:"center", justifyContent:"space-between",
          height:56,
        }}>
          <div style={{ display:"flex", alignItems:"center", gap:16 }}>
            <div style={{
              width:36, height:36,
              border:"1px solid #00ffe540",
              display:"flex", alignItems:"center", justifyContent:"center",
              fontSize:18, boxShadow:"0 0 15px #00ffe520",
              background:"#00ffe508",
            }}>⬡</div>
            <div>
              <div className={`orb ${glitch ? 'glitch':''}`} style={{ fontSize:14, fontWeight:800, color:"#00ffe5", letterSpacing:"0.2em", textShadow:"0 0 15px #00ffe580" }}>
                NEXUS·AI·AGENT
              </div>
              <div style={{ fontSize:9, color:"#2a5058", letterSpacing:"0.25em" }}>
                NVIDIA FREE INFERENCE · AUTONOMOUS OPERATIONS
              </div>
            </div>
          </div>

          <div style={{ display:"flex", alignItems:"center", gap:20 }}>
            {/* Status indicators */}
            {[
              { label:"BACKEND", ok: !!health },
              { label:"API KEY", ok: health?.api_key_set },
              { label:"AGENT",   ok: running },
            ].map(s => (
              <div key={s.label} style={{ display:"flex", alignItems:"center", gap:5, fontSize:9, letterSpacing:"0.1em" }}>
                <div className="status-dot" style={{ background: s.ok ? "#00ffe5" : "#1a3038", color: s.ok ? "#00ffe5" : "transparent", boxShadow: s.ok ? "0 0 8px #00ffe5" : "none" }} />
                <span style={{ color: s.ok ? "#3d6b72" : "#1a3038" }}>{s.label}</span>
              </div>
            ))}
            <div style={{ fontSize:9, color:"#1a3038", letterSpacing:"0.08em" }}>
              {new Date().toLocaleString('en-US',{hour12:false}).replace(',','')}
            </div>
          </div>
        </header>

        {/* ── TABS ── */}
        <div style={{ borderBottom:"1px solid #0a2028", padding:"0 24px", display:"flex", gap:4 }}>
          {[
            {id:"mission", label:"MISSION CONTROL"},
            {id:"intel",   label:`INTEL STREAM ${running ? '●':''}`},
            {id:"databank",label:`DATABANK [${files.length}]`},
          ].map(t => (
            <button key={t.id} className={`tab-btn ${tab===t.id?'active':''}`}
              onClick={() => setTab(t.id)}>
              {t.label}
            </button>
          ))}
        </div>

        {/* ── BODY ── */}
        <div style={{ flex:1, display:"flex", overflow:"hidden" }}>

          {/* ══ MISSION CONTROL TAB ══ */}
          {tab === "mission" && (
            <div style={{ flex:1, display:"flex", gap:0, overflow:"hidden" }}>

              {/* Left: Model + Format */}
              <div style={{
                width:260,
                borderRight:"1px solid #0a2028",
                padding:20,
                display:"flex", flexDirection:"column", gap:20,
                overflowY:"auto",
                background:"linear-gradient(90deg,#020408,transparent)",
              }}>
                <div>
                  <div className="orb" style={{ fontSize:9, color:"#2a5058", letterSpacing:"0.2em", marginBottom:12 }}>
                    SELECT MODEL
                  </div>
                  <div style={{ display:"flex", flexDirection:"column", gap:6 }}>
                    {MODELS.map(m => (
                      <div key={m.id}
                        className={`model-chip ${model===m.id?'active':''}`}
                        style={{ "--mc":m.color, "--mg":m.glow }}
                        onClick={() => setModel(m.id)}>
                        <div style={{ fontSize:11, color: model===m.id ? m.color : "#2a5058", fontWeight:600, letterSpacing:"0.08em" }}>
                          {m.name}
                        </div>
                        <div style={{ fontSize:10, color:"#1a3038", marginTop:2 }}>{m.sub}</div>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="orb" style={{ fontSize:9, color:"#2a5058", letterSpacing:"0.2em", marginBottom:10 }}>
                    OUTPUT FORMAT
                  </div>
                  <div style={{ display:"flex", gap:4, flexWrap:"wrap" }}>
                    {FORMATS.map(f => (
                      <button key={f.id}
                        className={`fmt-btn ${format===f.id?'active':''}`}
                        onClick={() => setFormat(f.id)}>
                        {f.icon} {f.label}
                      </button>
                    ))}
                  </div>
                  <div style={{ fontSize:10, color:"#1d4048", marginTop:8 }}>
                    {FORMATS.find(f=>f.id===format)?.desc}
                  </div>
                </div>

                {/* Active model display */}
                {selectedModel && (
                  <div className="hud-border" style={{ padding:12, background:"#020c0e" }}>
                    <div style={{ fontSize:9, color:"#1a3038", letterSpacing:"0.1em", marginBottom:6 }}>ACTIVE SYSTEM</div>
                    <div style={{ color:selectedModel.color, fontSize:11, textShadow:selectedModel.glow.replace('20px','8px') }}>
                      {selectedModel.name}
                    </div>
                    <div style={{ fontSize:10, color:"#2a5058", marginTop:4 }}>{selectedModel.sub}</div>
                  </div>
                )}
              </div>

              {/* Center: Task Input */}
              <div style={{
                flex:1, padding:24,
                display:"flex", flexDirection:"column", gap:16,
                overflowY:"auto",
              }}>
                <div className="orb" style={{ fontSize:9, color:"#2a5058", letterSpacing:"0.2em" }}>
                  MISSION OBJECTIVE
                </div>

                {/* Preset missions */}
                <div>
                  <div style={{ fontSize:9, color:"#1a3038", letterSpacing:"0.15em", marginBottom:8 }}>PRESET MISSIONS ▾</div>
                  <div style={{ display:"flex", flexWrap:"wrap", gap:4 }}>
                    {PRESETS.map((p,i) => (
                      <div key={i} className="preset-item" onClick={() => setTask(p.task)}>
                        {p.label}
                      </div>
                    ))}
                  </div>
                </div>

                <textarea
                  value={task}
                  onChange={e => setTask(e.target.value)}
                  placeholder="// Enter mission objective here...
// Examples:
// - Research latest GPU releases and save as CSV
// - Write a Python web scraper
// - Summarize AI news and save as markdown"
                  rows={8}
                  disabled={running}
                  style={{ lineHeight:1.7, borderRadius:3 }}
                />

                <div>
                  <div style={{ fontSize:9, color:"#1a3038", letterSpacing:"0.15em", marginBottom:6 }}>OUTPUT FILENAME (OPTIONAL)</div>
                  <input
                    value={filename}
                    onChange={e => setFilename(e.target.value)}
                    placeholder="mission_report  (extension auto-added)"
                    disabled={running}
                  />
                </div>

                <div style={{ display:"flex", gap:8, alignItems:"center" }}>
                  <button
                    className={`run-btn ${running?'running':''}`}
                    onClick={running ? stopAgent : runAgent}
                    disabled={!running && !task.trim()}>
                    {running ? "■ ABORT MISSION" : "▶ LAUNCH MISSION"}
                  </button>
                  {running && (
                    <div style={{ fontSize:10, color:"#ff6b35", letterSpacing:"0.1em", animation:"pulse-run 1.5s infinite" }}>
                      AGENT ACTIVE...
                    </div>
                  )}
                </div>

                {!health?.api_key_set && (
                  <div className="hud-border" style={{
                    padding:14,
                    background:"#0a0205",
                    borderColor:"#ff6b3520",
                  }}>
                    <div className="orb" style={{ fontSize:10, color:"#ff6b35", marginBottom:8, letterSpacing:"0.1em" }}>
                      ⚠ SYSTEM CONFIGURATION REQUIRED
                    </div>
                    <div style={{ fontSize:11, color:"#7a3828", lineHeight:2 }}>
                      1. Navigate to <span style={{color:"#00ffe5"}}>build.nvidia.com</span><br/>
                      2. Select any model → click "Get API Key"<br/>
                      3. Copy key (starts with nvapi-...)<br/>
                      4. Paste into <span style={{color:"#00ffe5"}}>backend/.env</span> as NVIDIA_API_KEY<br/>
                      5. Restart Python backend
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ══ INTEL STREAM TAB ══ */}
          {tab === "intel" && (
            <div style={{ flex:1, display:"flex", flexDirection:"column", background:"#020408" }}>
              <div style={{
                padding:"6px 20px", borderBottom:"1px solid #0a2028",
                display:"flex", alignItems:"center", gap:12, fontSize:10, color:"#1a3038",
                letterSpacing:"0.1em",
              }}>
                <span className="orb" style={{color:"#2a5058"}}>INTEL STREAM</span>
                {running && <span style={{color:"#00ffe5"}} className="orb">● LIVE</span>}
                <span style={{marginLeft:"auto"}}>{logs.length} EVENTS</span>
                <button onClick={() => setLogs([])} style={{
                  fontSize:9, padding:"2px 8px", border:"1px solid #0a2028",
                  background:"transparent", color:"#1a3038", cursor:"pointer",
                  fontFamily:"inherit", letterSpacing:"0.1em",
                }}>CLR</button>
              </div>

              <div ref={logsRef} style={{ flex:1, overflowY:"auto", padding:"16px 20px", display:"flex", flexDirection:"column", gap:2 }}>
                {logs.length === 0 && (
                  <div style={{ textAlign:"center", marginTop:100, color:"#0d2428" }}>
                    <div style={{ fontSize:40, marginBottom:16, opacity:0.3 }}>⬡</div>
                    <div className="orb" style={{ fontSize:12, letterSpacing:"0.2em" }}>AWAITING MISSION LAUNCH</div>
                    <div style={{ fontSize:10, marginTop:8, color:"#0a1e22" }}>Configure task in MISSION CONTROL and hit LAUNCH</div>
                  </div>
                )}

                {logs.map(l => {
                  const colors = {
                    boot:     "#00ffe560",
                    status:   "#4cc9f0",
                    stream:   "#a0c4cc",
                    search:   "#c77dff",
                    result:   "#3d5060",
                    fetch:    "#ff6b3580",
                    save:     "#00ffe5",
                    done:     "#00ffe5",
                    complete: "#00ffe5",
                    error:    "#ff4444",
                    warn:     "#ff9800",
                  };
                  return (
                    <div key={l.id} className="log-line">
                      <span className="log-time">{l.time}</span>
                      <span style={{
                        color: colors[l.type] || "#a0c4cc",
                        whiteSpace:"pre-wrap",
                        textShadow: l.type==="done"||l.type==="complete" ? "0 0 10px #00ffe540" : "none",
                        fontWeight: l.type==="done"||l.type==="complete" ? "600" : "normal",
                      }} className={l.type==="stream"&&running?"typing":""}>
                        {l.content}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ══ DATABANK TAB ══ */}
          {tab === "databank" && (
            <div style={{ flex:1, padding:24, overflowY:"auto" }}>
              <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:20 }}>
                <div className="orb" style={{ fontSize:9, color:"#2a5058", letterSpacing:"0.2em" }}>
                  DATABANK — {files.length} FILES STORED
                </div>
                <div style={{ fontSize:10, color:"#1a3038" }}>
                  ./backend/agent_outputs/
                </div>
              </div>

              {files.length === 0 && (
                <div style={{ textAlign:"center", marginTop:80, color:"#0d2428" }}>
                  <div style={{ fontSize:40, marginBottom:16, opacity:0.3 }}>📦</div>
                  <div className="orb" style={{ fontSize:12, letterSpacing:"0.2em" }}>DATABANK EMPTY</div>
                  <div style={{ fontSize:10, marginTop:8, color:"#0a1e22" }}>Run a mission to populate the databank</div>
                </div>
              )}

              <div style={{ display:"flex", flexDirection:"column", gap:6 }}>
                {files.map(f => {
                  const extColors = { ".csv":"#00ffe5", ".md":"#c77dff", ".txt":"#4cc9f0", ".py":"#ff6b35", ".js":"#ffd700", ".json":"#7fff00" };
                  const ec = extColors[f.ext] || "#a0c4cc";
                  const icons = { ".csv":"📊", ".md":"📝", ".txt":"📄", ".py":"🐍", ".js":"⚡", ".html":"🌐", ".json":"{ }" };
                  return (
                    <div key={f.name} className="file-row">
                      <div style={{ fontSize:20, opacity:0.8 }}>{icons[f.ext] || "📄"}</div>
                      <div style={{ flex:1 }}>
                        <div style={{ fontSize:13, color:ec, fontWeight:500, textShadow:`0 0 8px ${ec}40` }}>
                          {f.name}
                        </div>
                        <div style={{ fontSize:10, color:"#1d4048", marginTop:2 }}>
                          {formatBytes(f.size)} · {new Date(f.modified).toLocaleString()}
                        </div>
                      </div>
                      <div style={{ display:"flex", gap:6 }}>
                        <button className="dl-btn" onClick={() => window.open(`${API}/files/${f.name}`)}>
                          ↓ DOWNLOAD
                        </button>
                        <button
                          onClick={() => fetch(`${API}/files/${f.name}`,{method:"DELETE"}).then(loadFiles)}
                          style={{
                            fontSize:11, padding:"5px 10px",
                            border:"1px solid #0a2028", background:"transparent",
                            color:"#1a3038", cursor:"pointer", fontFamily:"inherit",
                            transition:"all 0.15s", borderRadius:2,
                          }}
                          onMouseEnter={e => { e.target.style.borderColor="#ff444440"; e.target.style.color="#ff4444"; }}
                          onMouseLeave={e => { e.target.style.borderColor="#0a2028"; e.target.style.color="#1a3038"; }}>
                          ✕
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {files.length > 0 && (
                <div className="hud-border" style={{ marginTop:20, padding:14, background:"#020c0e" }}>
                  <div style={{ fontSize:9, color:"#1a3038", letterSpacing:"0.15em", marginBottom:8 }}>SYSTEM PATH</div>
                  <code style={{ fontSize:11, color:"#00ffe560" }}>
                    {window.location.hostname === "localhost" ? `./backend/agent_outputs/` : "Files saved on your server"}
                  </code>
                </div>
              )}
            </div>
          )}

        </div>

        {/* ── FOOTER ── */}
        <footer style={{
          borderTop:"1px solid #0a2028",
          padding:"6px 24px",
          display:"flex", alignItems:"center", justifyContent:"space-between",
          fontSize:9, color:"#0d2428", letterSpacing:"0.12em",
          background:"linear-gradient(0deg,#020408,transparent)",
        }}>
          <span>NEXUS·AI·AGENT v2.0 · NVIDIA FREE INFERENCE ENDPOINTS</span>
          <span className="orb">
            {selectedModel && <span style={{color:selectedModel.color?.replace('5','3'), marginRight:12}}>{selectedModel.name}</span>}
            FORMAT:{format.toUpperCase()} · FILES:{files.length}
          </span>
        </footer>

      </div>
    </div>
  );
}
