from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
import httpx
import json
import os
import re
import asyncio
from datetime import datetime
from pathlib import Path
import urllib.parse

# ── API KEY — hardcoded directly ──────────────────────────────────────────
NVIDIA_API_KEY = "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"
NVIDIA_BASE_URL = "https://integrate.api.nvidia.com/v1"

print("=" * 60)
print("  NEXUS AI AGENT BACKEND")
print(f"  API Key: {NVIDIA_API_KEY[:16]}...{NVIDIA_API_KEY[-6:]}")
print("=" * 60)

# ── Output folder ─────────────────────────────────────────────────────────
OUTPUT_DIR = Path("./agent_outputs")
OUTPUT_DIR.mkdir(exist_ok=True)

# ── Models ────────────────────────────────────────────────────────────────
MODELS = {
    "nemotron-super": "nvidia/nemotron-3-super-120b-a12b",
    "mistral-small":  "mistralai/mistral-small-4-119b-2603",
    "kimi-k2":        "moonshotai/kimi-k2.5",
    "minimax-m2":     "minimaxai/minimax-m2.5",
}

# ── FastAPI app ────────────────────────────────────────────────────────────
app = FastAPI(title="NEXUS AI Agent")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── System prompt ──────────────────────────────────────────────────────────
SYSTEM_PROMPT = """You are NEXUS — an elite autonomous AI agent running on NVIDIA infrastructure.

Your capabilities:
- Deep web research via search queries
- Synthesizing information into structured reports
- Generating code in any language
- Analyzing and comparing data
- Producing structured data (CSV, JSON, TXT, MD)

When executing a task, follow this protocol:

1. Plan your approach briefly
2. Execute web searches with [SEARCH: query] — be specific, search multiple angles
3. Process results and continue reasoning
4. When ready to save output, use ONE of these blocks:

   [SAVE_TXT: filename.txt]
   full text content here
   [/SAVE]

   [SAVE_MD: filename.md]
   full markdown content here
   [/SAVE]

   [SAVE_CSV: filename.csv]
   Header1,Header2,Header3
   value1,value2,value3
   [/SAVE]

   [SAVE_CODE: filename.py]
   full code here
   [/SAVE]

5. End with [DONE: one sentence summary]

Be thorough. Search multiple angles. For CSV always include a proper header row.
"""


# ── Web search (DuckDuckGo — no API key needed) ────────────────────────────
async def web_search(query: str) -> str:
    try:
        encoded = urllib.parse.quote(query)
        async with httpx.AsyncClient(timeout=12) as client:
            r = await client.get(
                f"https://api.duckduckgo.com/?q={encoded}&format=json&no_html=1&skip_disambig=1",
                headers={"User-Agent": "Mozilla/5.0"}
            )
            data = r.json()

        results = []
        if data.get("AbstractText"):
            results.append(f"[OVERVIEW] {data['AbstractText'][:500]}")
        if data.get("AbstractURL"):
            results.append(f"[SOURCE] {data['AbstractURL']}")
        for topic in data.get("RelatedTopics", [])[:5]:
            if isinstance(topic, dict) and topic.get("Text"):
                results.append(f"• {topic['Text'][:200]}")

        if results:
            return "\n".join(results)

        # Fallback: scrape DuckDuckGo HTML
        async with httpx.AsyncClient(timeout=12) as client:
            r2 = await client.get(
                f"https://html.duckduckgo.com/html/?q={encoded}",
                headers={"User-Agent": "Mozilla/5.0"}
            )
        snippets = re.findall(r'class="result__snippet"[^>]*>(.*?)</a>', r2.text, re.DOTALL)
        titles   = re.findall(r'class="result__a"[^>]*>(.*?)</a>',       r2.text, re.DOTALL)
        clean = []
        for t, s in zip(titles[:5], snippets[:5]):
            ct = re.sub(r'<[^>]+>', '', t).strip()
            cs = re.sub(r'<[^>]+>', '', s).strip()
            if ct and cs:
                clean.append(f"• {ct}: {cs}")
        return "\n".join(clean) if clean else "No results found."
    except Exception as e:
        return f"Search error: {e}"


# ── Save file helper ───────────────────────────────────────────────────────
def save_output(filename: str, content: str, fmt: str = "txt") -> dict:
    safe = re.sub(r'[^\w\-_\.]', '_', filename.strip())
    valid_exts = ['.txt', '.md', '.csv', '.py', '.js', '.ts', '.html', '.json']
    if not any(safe.endswith(ext) for ext in valid_exts):
        ext_map = {"txt": ".txt", "md": ".md", "csv": ".csv", "code": ".py"}
        safe += ext_map.get(fmt, ".txt")
    path = OUTPUT_DIR / safe
    path.write_text(content, encoding="utf-8")
    return {
        "filename": safe,
        "path":     str(path),
        "size":     len(content.encode("utf-8")),
        "format":   fmt,
    }


# ── Call NVIDIA API with streaming ─────────────────────────────────────────
async def call_nvidia_stream(messages: list, model_key: str, ws: WebSocket) -> str:
    model = MODELS.get(model_key, MODELS["nemotron-super"])
    headers = {
        "Content-Type":  "application/json",
        "Authorization": f"Bearer {NVIDIA_API_KEY}",
    }
    payload = {
        "model":       model,
        "messages":    messages,
        "temperature": 0.6,
        "max_tokens":  3000,
        "stream":      True,
    }

    full_text = ""
    async with httpx.AsyncClient(timeout=180) as client:
        async with client.stream(
            "POST",
            f"{NVIDIA_BASE_URL}/chat/completions",
            headers=headers,
            json=payload,
        ) as resp:
            async for line in resp.aiter_lines():
                if line.startswith("data: ") and line != "data: [DONE]":
                    try:
                        chunk = json.loads(line[6:])
                        delta = chunk["choices"][0]["delta"].get("content", "")
                        if delta:
                            full_text += delta
                            await ws.send_json({"type": "token", "content": delta})
                    except Exception:
                        pass
    return full_text


# ── WebSocket agent endpoint ───────────────────────────────────────────────
@app.websocket("/ws/agent")
async def agent_websocket(ws: WebSocket):
    await ws.accept()
    try:
        data      = await ws.receive_json()
        task      = data.get("task", "").strip()
        model_key = data.get("model", "nemotron-super")
        filename  = data.get("filename") or f"output_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        fmt       = data.get("format", "txt")

        await ws.send_json({"type": "status",  "content": "NEXUS ONLINE — Initializing task..."})
        await ws.send_json({"type": "status",  "content": f"Model: {MODELS.get(model_key)}"})

        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user",   "content": f"TASK: {task}\nOutput format: {fmt}\nFilename hint: {filename}"},
        ]

        for iteration in range(1, 7):
            await ws.send_json({"type": "status", "content": f"Processing cycle {iteration}/6..."})

            # Call NVIDIA
            response = await call_nvidia_stream(messages, model_key, ws)
            messages.append({"role": "assistant", "content": response})

            # ── Handle [SEARCH: ...] requests ──
            searches = re.findall(r'\[SEARCH:\s*(.+?)\]', response)
            if searches:
                for query in searches:
                    await ws.send_json({"type": "searching", "query": query})
                    results = await web_search(query)
                    await ws.send_json({"type": "search_result", "query": query, "content": results})
                    messages.append({
                        "role": "user",
                        "content": f"Search results for '{query}':\n{results}\n\nContinue with the task."
                    })
                continue  # Go back to top so AI processes results

            # ── Handle file saves ──
            save_patterns = [
                (r'\[SAVE_TXT:\s*(.+?)\]([\s\S]+?)\[/SAVE\]',  "txt"),
                (r'\[SAVE_MD:\s*(.+?)\]([\s\S]+?)\[/SAVE\]',   "md"),
                (r'\[SAVE_CSV:\s*(.+?)\]([\s\S]+?)\[/SAVE\]',  "csv"),
                (r'\[SAVE_CODE:\s*(.+?)\]([\s\S]+?)\[/SAVE\]', "code"),
            ]
            for pattern, save_fmt in save_patterns:
                for match in re.finditer(pattern, response, re.DOTALL):
                    fname   = match.group(1).strip()
                    content = match.group(2).strip()
                    result  = save_output(fname, content, save_fmt)
                    await ws.send_json({"type": "file_saved", **result})

            # ── Check for [DONE] ──
            done = re.search(r'\[DONE:\s*(.+?)\]', response)
            summary = done.group(1) if done else "Task completed."
            await ws.send_json({"type": "done", "summary": summary})
            break

        await ws.send_json({"type": "complete"})

    except WebSocketDisconnect:
        pass
    except Exception as e:
        try:
            await ws.send_json({"type": "error", "content": f"Server error: {e}"})
        except Exception:
            pass


# ── File management ────────────────────────────────────────────────────────
@app.get("/files")
async def list_files():
    files = []
    for f in sorted(OUTPUT_DIR.iterdir(), key=lambda x: x.stat().st_mtime, reverse=True):
        if f.is_file():
            files.append({
                "name":     f.name,
                "size":     f.stat().st_size,
                "modified": datetime.fromtimestamp(f.stat().st_mtime).isoformat(),
                "ext":      f.suffix.lower(),
            })
    return files


@app.get("/files/{filename}")
async def get_file(filename: str):
    path = OUTPUT_DIR / filename
    if not path.exists():
        return {"error": "File not found"}
    return FileResponse(path, filename=filename)


@app.delete("/files/{filename}")
async def delete_file(filename: str):
    (OUTPUT_DIR / filename).unlink(missing_ok=True)
    return {"ok": True}


@app.get("/health")
async def health():
    return {
        "ok":          True,
        "api_key_set": True,
        "models":      list(MODELS.keys()),
        "output_dir":  str(OUTPUT_DIR.absolute()),
        "file_count":  len([f for f in OUTPUT_DIR.iterdir() if f.is_file()]),
    }


# ── Run ────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000)