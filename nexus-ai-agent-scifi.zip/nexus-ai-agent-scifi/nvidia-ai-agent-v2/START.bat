@echo off
title NEXUS AI AGENT
color 0A
echo.
echo  ╔════════════════════════════════════════════════╗
echo  ║   ⬡  NEXUS · AI · AGENT  v2.0                ║
echo  ║   NVIDIA FREE INFERENCE · SCI-FI EDITION      ║
echo  ╚════════════════════════════════════════════════╝
echo.

python --version >nul 2>&1 || (echo [ERROR] Python not found → https://python.org & pause & exit)
node --version   >nul 2>&1 || (echo [ERROR] Node.js not found → https://nodejs.org & pause & exit)

if not exist backend\.env (
    copy backend\.env.example backend\.env
    echo [!] Get FREE API key at build.nvidia.com then paste into backend\.env
    notepad backend\.env
    pause
)

echo [1/4] Installing Python deps...
cd backend & pip install -r requirements.txt -q & cd ..

echo [2/4] Installing frontend deps...
cd frontend & call npm install --silent & cd ..

echo [3/4] Starting NEXUS backend (port 8000)...
start "NEXUS Backend" cmd /k "cd backend && python main.py"
timeout /t 3 /nobreak >nul

echo [4/4] Starting NEXUS frontend (port 3000)...
start "NEXUS Frontend" cmd /k "cd frontend && npm run dev"
timeout /t 3 /nobreak >nul

echo.
echo  [✓] NEXUS ONLINE
echo  [✓] http://localhost:3000
echo.
start http://localhost:3000
pause
