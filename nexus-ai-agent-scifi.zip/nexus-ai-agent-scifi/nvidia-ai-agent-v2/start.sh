#!/bin/bash
echo ""
echo "  ⬡  NEXUS · AI · AGENT  v2.0"
echo "  NVIDIA FREE INFERENCE · SCI-FI EDITION"
echo ""

command -v python3 &>/dev/null || { echo "[ERR] Python3 missing → python.org"; exit 1; }
command -v node    &>/dev/null || { echo "[ERR] Node.js missing → nodejs.org"; exit 1; }

[ ! -f backend/.env ] && {
    cp backend/.env.example backend/.env
    echo "[!] Get FREE key at build.nvidia.com then edit backend/.env"
    ${EDITOR:-nano} backend/.env
}

echo "[1/4] Python deps..."
cd backend && pip3 install -r requirements.txt -q
export $(grep -v '^#' .env | xargs) 2>/dev/null || true
python3 main.py &
BPID=$!
cd ..

sleep 2

echo "[2/4] Frontend deps + launch..."
cd frontend && npm install --silent && npm run dev &
FPID=$!
cd ..

sleep 3
command -v open &>/dev/null && open http://localhost:3000
command -v xdg-open &>/dev/null && xdg-open http://localhost:3000

echo ""
echo "  [✓] NEXUS ONLINE → http://localhost:3000"
echo "  Ctrl+C to shutdown"
wait $BPID $FPID
